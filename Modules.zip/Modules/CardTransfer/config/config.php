<?php

return [
    'name' => 'CardTransfer',
];
