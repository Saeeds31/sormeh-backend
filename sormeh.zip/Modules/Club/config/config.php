<?php

return [
    'name' => 'Club',
];
